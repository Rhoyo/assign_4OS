Compile: gcc --std=gnu99 -pthread -o line_processor main.c
Executable: line_processor [<] input.txt [>] output.txt
